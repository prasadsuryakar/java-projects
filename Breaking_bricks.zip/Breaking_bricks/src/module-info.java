module Breaking_bricks {
	requires java.desktop;
}